# 文档约定

- 本目录保存 Noita 分析和后续 Godot 复刻资料。新增、修改文档前，先阅读对应 Obsidian skill。
- Markdown：`C:/Users/ahhh/.codex/skills/obsidian-markdown/SKILL.md`。
- Canvas：`C:/Users/ahhh/.codex/skills/json-canvas/SKILL.md`。
- Bases：`C:/Users/ahhh/.codex/skills/obsidian-bases/SKILL.md`；仅在需要数据视图时使用。
- 仓库操作：按需阅读 `C:/Users/ahhh/.codex/skills/obsidian-cli/SKILL.md`；外部网页提取和批量模板按需使用 defuddle、knap。
- 文档用中文，结论在前；保留必要字段、流程、来源和未知项，避免重复解释。
- 笔记顶部保留 title、aliases、tags、type、created、updated。内部用 wikilinks，外部用普通 Markdown 链接；表格内链接别名的竖线需转义。
- 原版事实标记【本地】或【公开】；工程方案标记【建议】；未验证内容标记【未知】或 question 提示块。
- 来源编号链接到「证据索引」；跨文档关系按需互链。新增系统后更新 README，必要时更新关系画布。
- 不把推测写成原版实现，不把格式调整写成行为验证。保持原配置、用户数据和技术结论可追溯。
- 完成后检查 YAML、内部链接、表格和 Canvas 引用；可用时在 Obsidian 阅读视图检查。

技能来源：https://github.com/kepano/obsidian-skills
安装提交：`3ccff5338ea700537839b21900aa5358a0402c98`。本目录规则由用户要求添加；技能内容以安装目录为准。
